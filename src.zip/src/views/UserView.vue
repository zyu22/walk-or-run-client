<template>
  <div class="flex h-full items-center justify-center">
    <div class="mx-auto flex max-w-7xl">
      <router-view></router-view>
    </div>
  </div>
</template>

<script setup></script>
